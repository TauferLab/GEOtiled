"""
::

     ____    ____    _____   ______     ___              __     
    /\  _`\ /\  _`\ /\  __`\/\__  _\__ /\_ \            /\ \    
    \ \ \L\_\ \ \L\_\ \ \/\ \/_/\ \/\_\\//\ \      __   \_\ \   
     \ \ \L_L\ \  _\L\ \ \ \ \ \ \ \/\ \ \ \ \   /'__`\ /'_` \  
      \ \ \/, \ \ \L\ \ \ \_\ \ \ \ \ \ \ \_\ \_/\  __//\ \L\ \ 
       \ \____/\ \____/\ \_____\ \ \_\ \_\/\____\ \____\ \___,_\ 
        \/___/  \/___/  \/_____/  \/_/\/_/\/____/\/____/\/__,_ /


GEOtiled: A Scalable Workflow for Generating Large Datasets of
High-Resolution Terrain Parameters

Refactored library. Compiled by Jay Ashworth
v0.0.1
GCLab 2023

Derived from original work by: Camila Roa (@CamilaR20), Eric Vaughan (@VaughanEric), Andrew Mueller (@Andym1098), Sam Baumann (@sam-baumann), David Huang (@dhuang0212), Ben Klein (@robobenklein)

`Read the paper here <https://dl.acm.org/doi/pdf/10.1145/3588195.3595941>`_

Terrain parameters such as slope, aspect, and hillshading are essential in various applications, including agriculture, forestry, and
hydrology. However, generating high-resolution terrain parameters is computationally intensive, making it challenging to provide
these value-added products to communities in need. We present a
scalable workflow called GEOtiled that leverages data partitioning
to accelerate the computation of terrain parameters from digital elevation models, while preserving accuracy. We assess our workflow
in terms of its accuracy and wall time by comparing it to SAGA,
which is highly accurate but slow to generate results, and to GDAL,
which supports memory optimizations but not data parallelism. We
obtain a coefficient of determination (𝑅2) between GEOtiled and
SAGA of 0.794, ensuring accuracy in our terrain parameters. We
achieve an X6 speedup compared to GDAL when generating the
terrain parameters at a high-resolution (10 m) for the Contiguous
United States (CONUS).
"""


import subprocess
import requests
from osgeo import gdal
import numpy as np
import matplotlib.pyplot as plt
import concurrent.futures
import os
from tqdm import tqdm
import math
from osgeo import osr
import pandas as pd
import geopandas as gpd
from somospie_lib import geoextras as ge

# ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

def bash(argv):
    """
    Execute bash commands using Popen.
    ----------------------------------

    This function acts as a wrapper to execute bash commands using the subprocess Popen method. Commands are executed synchronously, 
    and errors are caught and raised.

    Required Parameters
    -------------------
    argv : List
        List of arguments for a bash command. They should be in the order that you would arrange them in the command line (e.g., ["ls", "-lh", "~/"]).

    Outputs
    -------
    None
        The function does not return any value.

    Error States
    ------------
    RuntimeError
        Raises a RuntimeError if Popen returns with an error, detailing the error code, stdout, and stderr.

    Notes
    -----
    - It's essential to ensure that the arguments in the 'argv' list are correctly ordered and formatted for the desired bash command.
    """
    arg_seq = [str(arg) for arg in argv]
    proc = subprocess.Popen(arg_seq, stdout=subprocess.PIPE, stderr=subprocess.PIPE)#, shell=True)
    proc.wait() #... unless intentionally asynchronous
    stdout, stderr = proc.communicate()

    # Error catching: https://stackoverflow.com/questions/5826427/can-a-python-script-execute-a-function-inside-a-bash-script
    if proc.returncode != 0:
        raise RuntimeError("'%s' failed, error code: '%s', stdout: '%s', stderr: '%s'" % (
            ' '.join(arg_seq), proc.returncode, stdout.rstrip(), stderr.rstrip()))

# ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

def build_mosaic(input_files, output_file, description = "Elevation"):
    """
    Build a mosaic of geo-tiles using the GDAL library.
    ---------------------------------------------------

    This function creates a mosaic from a list of geo-tiles. 
    It is an integral part of the GEOTILED workflow and is frequently used for merging tiles into a single mosaic file.

    Required Parameters
    -------------------
    input_files : list of str
        List of strings containing paths to the geo-tiles that are to be merged.
    output_file : str
        String representing the desired location and filename for the output mosaic.

    Optional Parameters
    -------------------
    description : str, optional
        Description to attach to the output raster band. Default is "Elevation".

    Outputs
    -------
    None
        The function does not return any value. 
        Generates a .tif file representing the created mosaic. This file will be placed at the location specified by 'output_file'.

    Notes
    -----
    - Ensure the input geo-tiles are compatible for merging.
    - The function utilizes the GDAL library's capabilities to achieve the desired mosaic effect.
    """
    # input_files: list of .tif files to merge
    vrt = gdal.BuildVRT("merged.vrt", input_files)
    translate_options = gdal.TranslateOptions(creationOptions=['COMPRESS=LZW', 'TILED=YES', 'BIGTIFF=YES', 'NUM_THREADS=ALL_CPUS'],
                                              callback=gdal.TermProgress_nocb)
    gdal.Translate(output_file, vrt, options=translate_options)
    vrt = None  # closes file
    dataset = gdal.Open(output_file)
    band = dataset.GetRasterBand(1)
    band.SetDescription(description)
    dataset = None


# ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


def build_mosaic_filtered(input_files, output_file):
    """
    Build a mosaic of geo-tiles using the GDAL library with added logic to handle overlapping regions.
    ---------------------------------------------------------------------------------------------------

    This function creates a mosaic from a list of geo-tiles and introduces extra logic to handle averaging when regions overlap.
    The function is similar to `build_mosaic` but provides additional capabilities to ensure the integrity of data in overlapping regions.

    Required Parameters
    -------------------
    input_files : list of str
        List of strings containing paths to the geo-tiles to be merged.
    output_file : str
        String representing the desired location and filename for the output mosaic.

    Outputs
    -------
    None
        The function does not return any value.
        Generates a .tif file representing the created mosaic. This file is placed at the location specified by 'output_file'.

    Notes
    -----
    - The function makes use of the GDAL library's capabilities and introduces Python-based pixel functions to achieve the desired averaging effect.
    - The function is particularly useful when there are multiple sources of geo-data with possible overlapping regions,
      ensuring a smooth transition between tiles.
    - Overlapping regions in the mosaic are handled by averaging pixel values.
    """
    vrt = gdal.BuildVRT('merged.vrt', input_files)
    vrt = None  # closes file

    with open('merged.vrt', 'r') as f:
        contents = f.read()

    if '<NoDataValue>' in contents:
        nodata_value = contents[contents.index('<NoDataValue>') + len(
            '<NoDataValue>'): contents.index('</NoDataValue>')]  # To add averaging function
    else:
        nodata_value = 0

    code = '''band="1" subClass="VRTDerivedRasterBand">
  <PixelFunctionType>average</PixelFunctionType>
  <PixelFunctionLanguage>Python</PixelFunctionLanguage>
  <PixelFunctionCode><![CDATA[
import numpy as np

def average(in_ar, out_ar, xoff, yoff, xsize, ysize, raster_xsize,raster_ysize, buf_radius, gt, **kwargs):
    data = np.ma.array(in_ar, mask=np.equal(in_ar, {}))
    np.mean(data, axis=0, out=out_ar, dtype="float32")
    mask = np.all(data.mask,axis = 0)
    out_ar[mask] = {}
]]>
  </PixelFunctionCode>'''.format(nodata_value, nodata_value)

    sub1, sub2 = contents.split('band="1">', 1)
    contents = sub1 + code + sub2

    with open('merged.vrt', 'w') as f:
        f.write(contents)

    cmd = ['gdal_translate', '-co', 'COMPRESS=LZW', '-co', 'TILED=YES', '-co',
           'BIGTIFF=YES', '--config', 'GDAL_VRT_ENABLE_PYTHON', 'YES', 'merged.vrt', output_file]
    bash(cmd)

    

# ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

def build_stack(input_files, output_file):
    """
    Stack a list of .tif files into a single .tif file with multiple bands.
    ------------------------------------------------------------------------

    This function takes multiple .tif files and combines them into a single .tif file where each input file represents a separate band. 
    This operation is useful when multiple datasets, each represented by a separate .tif file, need to be combined into a single multi-band raster.

    Required Parameters
    -------------------
    input_files : list of str
        List of strings containing paths to the .tif files to be stacked.
    output_file : str
        String representing the desired location and filename for the output stacked raster.

    Outputs
    -------
    None
        The function does not return any value.
        A multi-band .tif file is generated at the location specified by 'output_file'.

    Notes
    -----
    - The function makes use of the GDAL library's capabilities to achieve the stacking operation.
    - Each input .tif file becomes a separate band in the output .tif file, retaining the order of the `input_files` list.
    """
    # input_files: list of .tif files to stack
    vrt_options = gdal.BuildVRTOptions(separate=True)
    vrt = gdal.BuildVRT("stack.vrt", input_files, options=vrt_options)
    translate_options = gdal.TranslateOptions(creationOptions=['COMPRESS=LZW', 'TILED=YES', 'BIGTIFF=YES'],
                                              callback=gdal.TermProgress_nocb)
    gdal.Translate(output_file, vrt, options=translate_options)
    vrt = None  # closes file

# ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

def change_raster_format(input_file, output_file, raster_format):
    """
    Convert the format of a given raster file.
    -------------------------------------------

    This function leverages the GDAL library to facilitate raster format conversion.
    It allows users to convert the format of their .tif raster files to several supported formats, 
    specifically highlighting the GTiff and NC4C formats.

    Required Parameters
    -------------------
    input_file : str
        String containing the path to the input .tif file.
    output_file : str
        String representing the desired location and filename for the output raster.
    raster_format : str
        String indicating the desired output format for the raster conversion. 
        Supported formats can be found at `GDAL Raster Formats <https://gdal.org/drivers/raster/index.html>`.
        This function explicitly supports GTiff and NC4C.

    Outputs
    -------
    None
        The function does not return any value.
        A raster file in the desired format is generated at the location specified by 'output_file'.

    Notes
    -----
    - While GTiff and NC4C formats have been explicitly mentioned, 
      the function supports several other formats as listed in the GDAL documentation.
    - The function sets specific creation options for certain formats. 
      For example, the GTiff format will use LZW compression, tiling, and support for large files.
    """

    # Supported formats: https://gdal.org/drivers/raster/index.html
    # SAGA, GTiff
    if raster_format == 'GTiff':
        translate_options = gdal.TranslateOptions(format=raster_format, creationOptions=['COMPRESS=LZW', 'TILED=YES', 'BIGTIFF=YES'],
                                                callback=gdal.TermProgress_nocb)
    elif raster_format == 'NC4C':
        translate_options = gdal.TranslateOptions(format=raster_format, creationOptions=['COMPRESS=DEFLATE'],
                                                callback=gdal.TermProgress_nocb)
    else:
        translate_options = gdal.TranslateOptions(format=raster_format,
                                                callback=gdal.TermProgress_nocb)
    
    gdal.Translate(output_file, input_file, options=translate_options)

# ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

def compute_geotiled(input_file):
    """
    Generate terrain parameters for an elevation model.
    ---------------------------------------------------

    This function uses the GDAL library to compute terrain parameters like slope, aspect, and hillshading 
    from a provided elevation model in .tif format.

    Parameters
    ----------
    input_file : str
        String containing the path to the input elevation model .tif.

    Returns
    -------
    None
        The function does not return any value.
        Generates terrain parameter files at the specified paths for slope, aspect, and hillshading.

    Notes
    -----
    - The function currently supports the following terrain parameters:
      - Slope
      - Aspect
      - Hillshading
    - The generated parameter files adopt the following GDAL creation options: 'COMPRESS=LZW', 'TILED=YES', and 'BIGTIFF=YES'.
    - The hillshading file undergoes an additional step to change its datatype to match that of the other parameters and 
      also sets its nodata value. The intermediate file used for this process is removed after the conversion.
    """

    out_folder = os.path.dirname(os.path.dirname(input_file))
    out_file = os.path.join(out_folder,'slope_tiles', os.path.basename(input_file))
    # Slope
    dem_options = gdal.DEMProcessingOptions(format='GTiff', creationOptions=['COMPRESS=LZW', 'TILED=YES', 'BIGTIFF=YES'])
    gdal.DEMProcessing(out_file, input_file, processing='slope', options=dem_options)

    #Adding 'Slope' name to band description 
    dataset = gdal.Open(out_file)
    band = dataset.GetRasterBand(1)
    band.SetDescription("Slope")
    dataset = None

    # Aspect
    out_file = os.path.join(out_folder,'aspect_tiles', os.path.basename(input_file))
    dem_options = gdal.DEMProcessingOptions(zeroForFlat=True, format='GTiff', creationOptions=['COMPRESS=LZW', 'TILED=YES', 'BIGTIFF=YES'])
    gdal.DEMProcessing(out_file, input_file, processing='aspect', options=dem_options)

    #Adding 'Aspect' name to band description 
    dataset = gdal.Open(out_file)
    band = dataset.GetRasterBand(1)
    band.SetDescription("Aspect")
    dataset = None
    
    # Hillshading
    out_file = os.path.join(out_folder,'hillshading_tiles', os.path.basename(input_file))
    dem_options = gdal.DEMProcessingOptions(format='GTiff', creationOptions=['COMPRESS=LZW', 'TILED=YES', 'BIGTIFF=YES'])
    gdal.DEMProcessing(out_file, input_file, processing='hillshade', options=dem_options)

    #Adding 'Hillshading' name to band description 
    dataset = gdal.Open(out_file)
    band = dataset.GetRasterBand(1)
    band.SetDescription("Hillshading")
    dataset = None

# ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

def crop_into_tiles(mosaic, out_folder, n_tiles):
    """
    Splits a geotiff file into n number of tiles.
    """
    n_tiles = math.sqrt(n_tiles)

    ds = gdal.Open(mosaic, 0)
    cols = ds.RasterXSize
    rows = ds.RasterYSize
    x_win_size = int(math.ceil(cols / n_tiles))
    y_win_size = int(math.ceil(rows / n_tiles))

    buffer = 10 # 10 pixels
    tile_count = 0

    for i in range(0, rows, y_win_size):
        if i + y_win_size < rows:
            nrows = y_win_size
        else:
            nrows = rows - i

        for j in range(0, cols, x_win_size):
            if j + x_win_size < cols:
                ncols = x_win_size
            else:
                ncols = cols - j

            tile_file = out_folder + '/tile_' + '{0:04d}'.format(tile_count) + '.tif'
            win = [j, i, ncols, nrows]

            # Upper left corner
            win[0] = max(0, win[0] - buffer)
            win[1] = max(0, win[1] - buffer)

            w = win[2] + 2*buffer
            win[2] = w if win[0] + w < cols else cols - win[0]

            h = win[3] + 2*buffer
            win[3] = h if win[1] + h < cols else cols - win[1]

            crop_pixels(mosaic, tile_file, win)
            tile_count += 1

# ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

def crop_to_valid_data(input_file, output_file, block_size=512):
    src_ds = gdal.Open(input_file, gdal.GA_ReadOnly)
    src_band = src_ds.GetRasterBand(1)
    
    no_data_value = src_band.GetNoDataValue()
    
    gt = src_ds.GetGeoTransform()
    
    # Initialize bounding box variables to None
    x_min, x_max, y_min, y_max = None, None, None, None

    for i in range(0, src_band.YSize, block_size):
        # Calculate block height to handle boundary conditions
        if i + block_size < src_band.YSize:
            actual_block_height = block_size
        else:
            actual_block_height = src_band.YSize - i

        for j in range(0, src_band.XSize, block_size):
            # Calculate block width to handle boundary conditions
            if j + block_size < src_band.XSize:
                actual_block_width = block_size
            else:
                actual_block_width = src_band.XSize - j

            block_data = src_band.ReadAsArray(j, i, actual_block_width, actual_block_height)
            
            rows, cols = np.where(block_data != no_data_value)
            
            if rows.size > 0 and cols.size > 0:
                if x_min is None or j + cols.min() < x_min:
                    x_min = j + cols.min()
                if x_max is None or j + cols.max() > x_max:
                    x_max = j + cols.max()
                if y_min is None or i + rows.min() < y_min:
                    y_min = i + rows.min()
                if y_max is None or i + rows.max() > y_max:
                    y_max = i + rows.max()

    # Convert pixel coordinates to georeferenced coordinates
    min_x = gt[0] + x_min * gt[1]
    max_x = gt[0] + (x_max + 1) * gt[1]
    min_y = gt[3] + (y_max + 1) * gt[5]
    max_y = gt[3] + y_min * gt[5]
    
    out_ds = gdal.Translate(output_file, src_ds, projWin=[min_x, max_y, max_x, min_y], projWinSRS='EPSG:4326')
    
    out_ds = None
    src_ds = None

# def process_block(args):
#     src_band, no_data_value, j, i, block_size = args
#     block_data = src_band.ReadAsArray(j, i, block_size, block_size)
#     rows, cols = np.where(block_data != no_data_value)

#     if rows.size == 0 or cols.size == 0:
#         return None

#     return j + cols.min(), j + cols.max(), i + rows.min(), i + rows.max()

# def crop_to_valid_data(input_file, output_file, block_size = 512):
#     """
#     Crop a raster to its valid data extent.
#     ---------------------------------------
    
#     This function trims out the regions with no-data values and crops a raster to the area containing valid data.

#     Parameters
#     ----------
#     input_file : str
#         Path to the input raster file that will be cropped.
#     output_file : str
#         Path where the cropped raster will be saved.
#     block_size : int
#         Size of the block used for computing the bounds of the nodata values. 
    
#     Returns
#     -------
#     None
#         The function does not return any value. The cropped raster is saved directly to the specified output file.
    
#     Notes
#     -----
#     - The function uses the GDAL library for raster operations.
#     - Assumes the no-data value is set for the input raster.
#     - The cropping region is determined based on the bounding box of valid data (values that are not no-data).
#     """
#     src_ds = gdal.Open(input_file, gdal.GA_ReadOnly)
#     src_band = src_ds.GetRasterBand(1)
#     no_data_value = src_band.GetNoDataValue()
#     gt = src_ds.GetGeoTransform()
    
#     args_list = [(src_band, no_data_value, j, i, block_size) 
#                  for i in range(0, src_band.YSize, block_size) 
#                  for j in range(0, src_band.XSize, block_size)]

#     # Use ThreadPoolExecutor to process blocks in parallel
#     with concurrent.futures.ThreadPoolExecutor() as executor:
#         results = list(executor.map(process_block, args_list))

#     results = [r for r in results if r is not None]
#     x_min = min(r[0] for r in results)
#     x_max = max(r[1] for r in results)
#     y_min = min(r[2] for r in results)
#     y_max = max(r[3] for r in results)

#     # Convert pixel coordinates to georeferenced coordinates
#     min_x = gt[0] + x_min * gt[1]
#     max_x = gt[0] + (x_max + 1) * gt[1]
#     min_y = gt[3] + (y_max + 1) * gt[5]
#     max_y = gt[3] + y_min * gt[5]

    # gdal.SetConfigOption('GDAL_NUM_THREADS', 'ALL_CPUS')
#     out_ds = gdal.Translate(output_file, src_ds, projWin=[min_x, max_y, max_x, min_y], projWinSRS='EPSG:4326')

#     # Free memory
#     out_ds = None
#     src_ds = None



# ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


def crop_pixels(input_file, output_file, window):
    """
    Crop a raster file to a specific region using provided pixel window.
    ---------------------------------------------------------------------

    This function uses the GDAL library to perform the cropping operation based on pixel coordinates 
    rather than geospatial coordinates.

    Required Parameters
    -------------------
    input_file : str
        String representing the path to the input raster file to be cropped.
    output_file : str
        String representing the path where the cropped raster file should be saved.
    window : list or tuple
        List or tuple specifying the window to crop by in the format [left_x, top_y, width, height].
        Here, left_x and top_y are the pixel coordinates of the upper-left corner of the cropping window,
        while width and height specify the dimensions of the cropping window in pixels.

    Outputs
    -------
    None
        A cropped raster file saved at the specified output_file path.

    Notes
    -----
    - The function uses GDAL's Translate method with the `srcWin` option to perform the pixel-based cropping.
    - Must ensure that GDAL is properly installed to utilize this function.

    Error States
    ------------
    - If the specified pixel window is outside the bounds of the input raster, an error might be raised by GDAL.
    """

    # Window to crop by [left_x, top_y, width, height]
    translate_options = gdal.TranslateOptions(srcWin=window,
                                              creationOptions=[
                                                  'COMPRESS=LZW', 'TILED=YES', 'BIGTIFF=YES'],
                                              callback=gdal.TermProgress_nocb)
    gdal.Translate(output_file, input_file, options=translate_options)


# ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


def download_file(url, folder, pbar):
    """
    Download a single file given its URL and store it in a specified path.
    -----------------------------------------------------------------------

    This is a utility function that facilitates the downloading of files, especially within iterative download operations.

    Required Parameters
    -------------------
    url : str
        String containing the URL of the file intended for downloading.
    folder : str
        String specifying the path where the downloaded file will be stored.
    pbar : tqdm object
        Reference to the tqdm progress bar, typically used in a parent function to indicate download progress.

    Outputs
    -------
    int
        Returns an integer representing the number of bytes downloaded.
    None
        Creates a file in the designated 'folder' upon successful download.

    Notes
    -----
    - If the file already exists in the specified folder, no download occurs, and the function returns 0.
    - Utilizes the requests library for file retrieval and tqdm for progress visualization.
    """
    local_filename = os.path.join(folder, url.split('/')[-1])
    if os.path.exists(local_filename):
        return 0

    response = requests.get(url, stream=True)
    downloaded_size = 0
    with open(local_filename, 'wb') as f:
        for chunk in response.iter_content(chunk_size=8192):
            f.write(chunk)
            downloaded_size += len(chunk)
            pbar.update(len(chunk))
    return downloaded_size

# ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


def download_files(input, folder="./"):
    """
    Download one or multiple files from provided URLs.
    ---------------------------------------------------

    This function allows for the simultaneous downloading of files using threading, and showcases download progress via a tqdm progress bar.

    Required Parameters
    -------------------
    input : str or list of str
        Can either be:
        1. A string specifying the path to a .txt file. This file should contain URLs separated by newlines.
        2. A list of strings where each string is a URL.
    
    Optional Parameters
    -------------------
    folder : str, optional
        String denoting the directory where the downloaded files will be stored. Default is the current directory.

    Outputs
    -------
    None
        Downloads files and stores them in the specified 'folder'.

    Notes
    -----
    - The function uses `ThreadPoolExecutor` from the `concurrent.futures` library to achieve multi-threaded downloads for efficiency.
    - The tqdm progress bar displays the download progress.
    - If the 'input' argument is a string, it's assumed to be the path to a .txt file containing URLs.
    - Will not download files if the file already exists, but the progress bar will not reflect it. 
    """
    if isinstance(input, str):
        with open(input, 'r', encoding='utf8') as dsvfile:
            urls = [url.strip().replace("'$", "")
                    for url in dsvfile.readlines()]
    else:
        urls = input
    print(input)
    total_size = sum(get_file_size(url.strip()) for url in urls)
    downloaded_size = 0

    with tqdm(total=total_size, unit='B', unit_scale=True, ncols=100, desc="Downloading", colour='green') as pbar:
        with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
            futures = [executor.submit(
                download_file, url, folder, pbar) for url in urls]
            for future in concurrent.futures.as_completed(futures):
                size = future.result()
                downloaded_size += size


# ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
def fetch_dem(bbox={"xmin": -84.0387, "ymin": 35.86, "xmax": -83.815, "ymax": 36.04}, shapefile="./OK.zip", dataset="National Elevation Dataset (NED) 1/3 arc-second Current", prod_format="GeoTIFF", download=False, txtPath="download_urls.txt", saveToTxt=True, downloadFolder='./'):
    """
    Queries the USGS API for DEM data given specified parameters and optionally extracts download URLs.
    ----------------------------------------------------------------------------------------------------

    The function targets the USGS National Map API, fetching Digital Elevation Model (DEM) data based on provided parameters. It can automatically download these files or save their URLs to a .txt file.

    Required Parameters
    -------------------
    bbox : dict, optional
        Dictionary containing bounding box coordinates to query. Consists of xmin, ymin, xmax, ymax. Default is {"xmin": -84.0387, "ymin": 35.86, "xmax": -83.815, "ymax": 36.04}.

    Optional Parameters
    -------------------
    shapefile : str, optional
        [WIP] Path to the shapefile for query. Note: Cannot be used concurrently with `bbox`. Default is "./OK.zip".
    dataset : str, optional
        Specifies the USGS dataset to target. Default is "National Elevation Dataset (NED) 1/3 arc-second Current".
    prod_format : str, optional
        Desired file format for the downloads. Default is "GeoTIFF".
    download : bool, optional
        If set to True, triggers automatic file downloads. Default is False.
    txtPath : str, optional
        Designated path to save the .txt file containing URLs. Default is "download_urls.txt".
    saveToTxt : bool, optional
        Flag to determine if URLs should be saved to a .txt file. Default is True.
    downloadFolder : str, optional
        Destination folder for downloads (used if `download` is True). Default is the current directory.

    Outputs
    -------
    None
        Depending on configurations, either saves URLs to a .txt file or initiates downloads using the `download_files` function.

    Notes
    -----
    - If both `bbox` and `shapefile` are provided, `bbox` will take precedence.
    - Uses the USGS National Map API for data fetching. Ensure the chosen dataset and product format are valid.
    """
    
    base_url = "https://tnmaccess.nationalmap.gov/api/v1/products"

    # Construct the query parameters
    params = {
        "bbox": f"{bbox['xmin']},{bbox['ymin']},{bbox['xmax']},{bbox['ymax']}",
        # "extentQuery" : shapefile,
        "datasets": dataset,
        "prodFormats": prod_format
    }

    # Make a GET request
    response = requests.get(base_url, params=params)

    # Check for a successful request
    if response.status_code != 200:
        raise Exception(
            f"Failed to fetch data. Status code: {response.status_code}")

    # Convert JSON response to Python dict
    data = response.json()

    # Extract download URLs
    download_urls = [item['downloadURL'] for item in data['items']]

    if saveToTxt is True:
        with open(txtPath, "w") as file:
            for url in download_urls:
                file.write(f"{url}\n")

    if download is True:
        download_files(download_urls, folder=downloadFolder)


# ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

def generate_img(tif, cmap='inferno', dpi=150, downsample=1, verbose=False, clean=False, title=None, 
                 nancolor='green', ztype="Z", zunit=None, xyunit=None, reproject_gcs=False, 
                 shp_files =None, crop_shp=False, bordercolor="black", borderlinewidth=1.5):
    """
    Plot a GeoTIFF image using matplotlib.
    --------------------------------------

    This function is a powerful plotting tool for GEOTiff files that uses GDAL, OSR, numpy, matplotlib, and geopandas. 
    We have tried to create a simple interface for the end user where you can input a tif file and an informational image will be generated.
    If the default image is not suited for your needs or if any of the information is incorrect, there are a series of keyword arguments that allow for user customizability. 

    Several major features that are not enabled by default include:

    - Automatic PCS to GCS conversion using the ``reproject_gcs`` flag.
    - Automated cropping with a shapefile using the ``shp_file`` parameter in addition to the ``crop_shp``.
    - Downsampling in order to reduce computation time using the ``downsample`` flag. 
    - A verbose mode that will print additional spatial information about the geotiff file using the ``verbose`` flag.
    - A clean mode that will print an image of the geotiff with no other information using the ``clean`` flag. 

    Required Parameters
    --------------------
    tif : str
        Path to the GeoTIFF file.

    Optional Parameters
    -------------------
    cmap : str, optional
        Colormap used for visualization. Default is 'inferno'.
    dpi : int, optional
        Resolution in dots per inch for the figure. Default is 150.
    downsample : int, optional
        Factor to downsample the image by. Default is 10.
    verbose : bool, optional
        If True, print geotransform and spatial reference details. Default is False.
    clean : bool, optional
        If True, no extra data will be shown besides the plot image. Default is False.
    title : str, optional
        Title for the plot. Default will display the projection name.
    nancolor : str, optional
        Color to use for NaN values. Default is 'green'.
    ztype : str, optional
        Data that is represented by the z-axis. Default is 'Z'.
    zunit : str, optional
        Units for the data values (z-axis). Default is None and inferred from spatial reference.
    xyunit : str, optional
        Units for the x and y axes. Default is None and inferred from spatial reference.
    reproject_gcs : bool, optional
        Reproject a given raster from a projected coordinate system (PCS) into a geographic coordinate system (GCS).
    shp_file : str, optional
        Path to the shapefile used for cropping. Default is None.
    crop_shp : bool, optional
        Flag to indicate if the shapefile should be used for cropping. Default is False.
    bordercolor : str, optional
        Color for the shapefile boundary. Default is "black".
    borderlinewidth : float, optional
        Line width for the shapefile boundary. Default is 1.5.

    Returns
    -------
    None
        Will print an image to display using matplotlib in Jupyter Notebook.

    Notes
    -----
    - Alternative colormaps can be found in the `matplotlib documentation <https://matplotlib.org/stable/users/explain/colors/colormaps.html>`_.
    - Shapemap cannot be in a .zip form. GDAL will throw an error if you use a .zip. We recommend using .shp. 
    - Must be used with Jupyter Notebooks to display results properly.
    - Using ``shp_file`` without setting ``crop_shp`` will allow you to plot the outline of the shapefile without actually cropping anything. 
    """


    # Initial setup
    tif_dir_changed = False
    
    # Reproject raster into geographic coordinate system if needed
    if reproject_gcs:
        print("Reprojecting..")
        base_dir = os.path.dirname(tif)
        new_path = os.path.join(base_dir, "vis.tif")
        reproject(tif, new_path, "EPSG:4326")
        if crop_shp is False:
            new_path_crop = os.path.join(base_dir, "vis_trim_crop.tif")
            print("Cropping NaN values...")
            crop_to_valid_data(new_path,new_path_crop)
            print("Done.")
            os.remove(new_path)
            tif = new_path_crop
        else:
            tif = new_path
        tif_dir_changed = True

    # Crop using shapefiles if needed
    if crop_shp and shp_files:
        # Check if the list is not empty
        if not shp_files:
            print("Shapefile list is empty. Skipping shapefile cropping.")
        else:
            # Read each shapefile, clean any invalid geometries, and union them
            gdfs = [gpd.read_file(shp_file).buffer(0) for shp_file in shp_files]
            combined_geom = gdfs[0].unary_union
            for gdf in gdfs[1:]:
                combined_geom = combined_geom.union(gdf.unary_union)
            
            combined_gdf = gpd.GeoDataFrame(geometry=[combined_geom], crs=gdfs[0].crs)
                
            # Save the combined shapefile temporarily for cropping
            temp_combined_shp = os.path.join(os.path.dirname(tif), "temp_combined.shp")
            combined_gdf.to_file(temp_combined_shp)
                
            print("Cropping with combined shapefiles...")
            base_dir = os.path.dirname(tif)
            new_path = os.path.join(base_dir, "crop.tif")
            ge.crop_region(tif, temp_combined_shp, new_path)
            if tif_dir_changed:
                os.remove(tif)
            tif = new_path
            tif_dir_changed = True
            print("Done.")
            
            # Remove the temporary combined shapefile
            os.remove(temp_combined_shp)

    print("Reading in tif for visualization...")
    dataset = gdal.Open(tif)
    band = dataset.GetRasterBand(1)

    geotransform = dataset.GetGeoTransform()
    spatial_ref = osr.SpatialReference(wkt=dataset.GetProjection())

    # Extract spatial information about raster
    proj_name = spatial_ref.GetAttrValue('PROJECTION')
    proj_name = proj_name if proj_name else "GCS, No Projection"
    data_unit = zunit or spatial_ref.GetLinearUnitsName()
    coord_unit = xyunit or spatial_ref.GetAngularUnitsName()
    z_type = ztype if band.GetDescription() is '' else band.GetDescription()


    if verbose:
        print(f"Geotransform:\n{geotransform}\n\nSpatial Reference:\n{spatial_ref}\n\nDocumentation on spatial reference format: https://docs.ogc.org/is/18-010r11/18-010r11.pdf\n")

    raster_array = gdal.Warp('', tif, format='MEM', 
                             width=int(dataset.RasterXSize/downsample), 
                             height=int(dataset.RasterYSize/downsample)).ReadAsArray()

    # Mask nodata values
    raster_array = np.ma.array(raster_array, mask=np.equal(raster_array, band.GetNoDataValue()))

    print("Done.\nPlotting data...")

    # Set up plotting environment
    cmap_instance = plt.get_cmap(cmap)
    cmap_instance.set_bad(color=nancolor)

    # Determine extent
    ulx, xres, _, uly, _, yres = geotransform
    lrx = ulx + (dataset.RasterXSize * xres)
    lry = uly + (dataset.RasterYSize * yres)

    # Plot
    fig, ax = plt.subplots(dpi=dpi)
    sm = ax.imshow(raster_array, cmap=cmap_instance, vmin=np.nanmin(raster_array), vmax=np.nanmax(raster_array), 
                   extent=[ulx, lrx, lry, uly])
    if clean:
        ax.axis('off')
    else:
        # Adjust colorbar and title
        cbar = fig.colorbar(sm, fraction=0.046*raster_array.shape[0]/raster_array.shape[1], pad=0.04)
        cbar_ticks = np.linspace(np.nanmin(raster_array), np.nanmax(raster_array), 8)
        cbar.set_ticks(cbar_ticks)
        cbar.set_label(f"{z_type} ({data_unit}s)")

        ax.set_title(title if title else f"Visualization of GEOTiff data using {proj_name}.", fontweight='bold')
        ax.tick_params(axis='both', which='both', bottom=True, top=False, left=True, right=False, color='black', length=5, width=1)

        ax.set_title(title or f"Visualization of GEOTiff data using {proj_name}.", fontweight='bold')

    # Set up the ticks for x and y axis
    x_ticks = np.linspace(ulx, lrx, 5)
    y_ticks = np.linspace(lry, uly, 5)

    # Format the tick labels to two decimal places
    x_tick_labels = [f'{tick:.2f}' for tick in x_ticks]
    y_tick_labels = [f'{tick:.2f}' for tick in y_ticks]

    ax.set_xticks(x_ticks)
    ax.set_yticks(y_ticks)
    ax.set_xticklabels(x_tick_labels)
    ax.set_yticklabels(y_tick_labels)


    # Determine x and y labels based on whether data is lat-long or projected
    y_label = f"Latitude ({coord_unit}s)" if spatial_ref.EPSGTreatsAsLatLong() else f"Northing ({coord_unit}s)"
    x_label = f"Longitude ({coord_unit}s)" if spatial_ref.EPSGTreatsAsLatLong() else f"Easting ({coord_unit}s)"
    ax.set_ylabel(y_label)
    ax.set_xlabel(x_label)

    ax.ticklabel_format(style='plain', axis='both')  # Prevent scientific notation on tick labels
    ax.set_aspect('equal')

    if shp_files:
        for shp_file in shp_files:
            overlay = gpd.read_file(shp_file)
            overlay.boundary.plot(color=bordercolor, linewidth=borderlinewidth, ax=ax)

    print("Done. (image should appear soon...)")

    if tif_dir_changed:
        os.remove(tif)


# Add any other necessary imports here

def generate_img_multiband(tif, cmap='inferno', dpi=150, downsample=1, verbose=False, clean=False, title=None, 
                 nancolor='green', ztype="Z", zunit=None, xyunit=None, reproject_gcs=False, 
                 shp_files=None, crop_shp=False, bordercolor="black", borderlinewidth=1.5):
    
    # Initial setup
    tif_dir_changed = False
    
    # Reproject raster into geographic coordinate system if needed
    if reproject_gcs:
        print("Reprojecting..")
        base_dir = os.path.dirname(tif)
        new_path = os.path.join(base_dir, "vis.tif")
        reproject(tif, new_path, "EPSG:4326")
        if crop_shp is False:
            new_path_crop = os.path.join(base_dir, "vis_trim_crop.tif")
            print("Cropping NaN values...")
            crop_to_valid_data(new_path,new_path_crop)
            print("Done.")
            os.remove(new_path)
            tif = new_path_crop
        else:
            tif = new_path
        tif_dir_changed = True

    # Crop using shapefiles if needed
    if crop_shp and shp_files:
        # Check if the list is not empty
        if not shp_files:
            print("Shapefile list is empty. Skipping shapefile cropping.")
        else:
            # Read each shapefile, clean any invalid geometries, and union them
            gdfs = [gpd.read_file(shp_file).buffer(0) for shp_file in shp_files]
            combined_geom = gdfs[0].unary_union
            for gdf in gdfs[1:]:
                combined_geom = combined_geom.union(gdf.unary_union)
            
            combined_gdf = gpd.GeoDataFrame(geometry=[combined_geom], crs=gdfs[0].crs)
                
            # Save the combined shapefile temporarily for cropping
            temp_combined_shp = os.path.join(os.path.dirname(tif), "temp_combined.shp")
            combined_gdf.to_file(temp_combined_shp)
                
            print("Cropping with combined shapefiles...")
            base_dir = os.path.dirname(tif)
            new_path = os.path.join(base_dir, "crop.tif")
            ge.crop_region(tif, temp_combined_shp, new_path)
            if tif_dir_changed:
                os.remove(tif)
            tif = new_path
            tif_dir_changed = True
            print("Done.")
            
            # Remove the temporary combined shapefile
            os.remove(temp_combined_shp)
    
    print("Reading in tif for visualization...")
    dataset = gdal.Open(tif)
    num_bands = dataset.RasterCount  # Get the number of bands in the dataset
    
    if num_bands == 1:  # If only one band, the function behaves the same way as before
        bands = [dataset.GetRasterBand(1)]
    else:
        bands = [dataset.GetRasterBand(i) for i in range(1, num_bands+1)]
    
    # Extract spatial information about raster
    geotransform = dataset.GetGeoTransform()
    spatial_ref = osr.SpatialReference(wkt=dataset.GetProjection())

    # Extract spatial information about raster
    proj_name = spatial_ref.GetAttrValue('PROJECTION')
    proj_name = proj_name if proj_name else "GCS, No Projection"
    data_unit = zunit or spatial_ref.GetLinearUnitsName()
    coord_unit = xyunit or spatial_ref.GetAngularUnitsName()
    z_type = ztype if dataset.GetRasterBand(1).GetDescription() is '' else dataset.GetRasterBand(1).GetDescription()



    if verbose:
        print(f"Geotransform:\n{geotransform}\n\nSpatial Reference:\n{spatial_ref}\n\nDocumentation on spatial reference format: https://docs.ogc.org/is/18-010r11/18-010r11.pdf\n")

    raster_array = gdal.Warp('', tif, format='MEM', 
                             width=int(dataset.RasterXSize/downsample), 
                             height=int(dataset.RasterYSize/downsample)).ReadAsArray()

    # Mask nodata values
    # raster_array = np.ma.array(raster_array, mask=np.equal(raster_array, band.GetNoDataValue()))

    print("Done.\nPlotting data...")

    # Set up plotting environment
    cmap_instance = plt.get_cmap(cmap)
    cmap_instance.set_bad(color=nancolor)

    # Determine extent
    ulx, xres, _, uly, _, yres = geotransform
    lrx = ulx + (dataset.RasterXSize * xres)
    lry = uly + (dataset.RasterYSize * yres)

    
    fig, axes = plt.subplots(nrows=1, ncols=num_bands, dpi=dpi, figsize=(5*num_bands, 5))
    if num_bands == 1:
        axes = [axes]
    
    for idx, band in enumerate(bands):
        raster_array = band.ReadAsArray(
            0, 0,
            dataset.RasterXSize,
            dataset.RasterYSize,
            int(dataset.RasterXSize/downsample),
            int(dataset.RasterYSize/downsample)
        )
        raster_array = np.ma.array(raster_array, mask=np.equal(raster_array, band.GetNoDataValue()))
        ax = axes[idx]
        
        cmap_instance = plt.get_cmap(cmap)
        cmap_instance.set_bad(color=nancolor)
        sm = ax.imshow(raster_array, cmap=cmap_instance, vmin=np.nanmin(raster_array), vmax=np.nanmax(raster_array), 
                       extent=[ulx, lrx, lry, uly])
        
        # The rest of the plotting part for individual bands
        # Adjust for axes, titles, colorbars, etc.
        if clean:
            ax.axis('off')
        else:
            # Adjust colorbar and title
            cbar = fig.colorbar(sm, fraction=0.046*raster_array.shape[0]/raster_array.shape[1], pad=0.04)
            cbar_ticks = np.linspace(np.nanmin(raster_array), np.nanmax(raster_array), 8)
            cbar.set_ticks(cbar_ticks)
            cbar.set_label(f"{z_type} ({data_unit}s)")

            ax.set_title(title if title else f"Visualization of GEOTiff data using {proj_name}.", fontweight='bold')
            ax.tick_params(axis='both', which='both', bottom=True, top=False, left=True, right=False, color='black', length=5, width=1)

            ax.set_title(title or f"Visualization of GEOTiff data using {proj_name}.", fontweight='bold')

        # Set up the ticks for x and y axis
        x_ticks = np.linspace(ulx, lrx, 5)
        y_ticks = np.linspace(lry, uly, 5)
        ax.set_xticks(x_ticks)
        ax.set_yticks(y_ticks)

        # Determine x and y labels based on whether data is lat-long or projected
        y_label = f"Latitude ({coord_unit}s)" if spatial_ref.EPSGTreatsAsLatLong() else f"Northing ({coord_unit}s)"
        x_label = f"Longitude ({coord_unit}s)" if spatial_ref.EPSGTreatsAsLatLong() else f"Easting ({coord_unit}s)"
        ax.set_ylabel(y_label)
        ax.set_xlabel(x_label)

        ax.ticklabel_format(style='plain', axis='both')  # Prevent scientific notation on tick labels
        ax.set_aspect('equal')
        
        if shp_files:
            for shp_file in shp_files:
                overlay = gpd.read_file(shp_file)
                overlay.boundary.plot(color=bordercolor, linewidth=borderlinewidth, ax=ax)

    # Additional adjustment for overall title and layout
    plt.tight_layout()
    plt.subplots_adjust(wspace=0.5)
    plt.suptitle(title or f"Visualization of GEOTiff data using {proj_name}.", fontweight='bold')
    
    print("Done. (image should appear soon...)")
    
    if tif_dir_changed:
        os.remove(tif)

    
# ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

def get_file_size(url):
    """
    Retrieve the size of a file at a given URL in bytes.
    ----------------------------------------------------

    This function sends a HEAD request to the provided URL and reads the 'Content-Length' header to determine the size of the file. 
    It's primarily designed to support the `download_files` function to calculate download sizes beforehand.

    Required Parameters
    -------------------
    url : str
        String representing the URL from which the file size needs to be determined.

    Outputs
    -------
    int
        Size of the file at the specified URL in bytes. Returns 0 if the size cannot be determined.

    Notes
    -----
    - This function relies on the server's response headers to determine the file size.
    - If the server doesn't provide a 'Content-Length' header or there's an error in the request, the function will return 0.
    """
    try:
        response = requests.head(url)
        return int(response.headers.get('Content-Length', 0))
    except:
        return 0

# ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


def reproject(input_file, output_file, projection):
    """
    Reproject a geospatial raster dataset (GeoTIFF) using the GDAL library.
    -------------------------------------------------------------------------

    This function reprojects a given GeoTIFF raster dataset from its original coordinate system to a new specified projection. The result is saved as a new raster file. The projection can be provided in multiple formats, including standard EPSG codes or WKT format.

    Required Parameters
    -------------------
    input_file : str
        String representing the file location of the GeoTIFF to be reprojected.
    output_file : str
        String representing the desired location and filename for the output reprojected raster.
    projection : str
        String indicating the desired target projection. This can be a standard GDAL format code (e.g., EPSG:4326) or the path to a .wkt file.

    Outputs
    -------
    None
        Generates a reprojected GeoTIFF file at the specified 'output_file' location.

    Notes
    -----
    - The function supports multi-threading for improved performance on multi-core machines.
    - The source raster data remains unchanged; only a new reprojected output file is generated.
    """
    # Projection can be EPSG:4326, .... or the path to a wkt file
    warp_options = gdal.WarpOptions(dstSRS=projection, creationOptions=['COMPRESS=LZW', 'TILED=YES', 'BIGTIFF=YES', 'NUM_THREADS=ALL_CPUS'],
                                    callback=gdal.TermProgress_nocb, multithread=True, warpOptions=['NUM_THREADS=ALL_CPUS'])
    warp = gdal.Warp(output_file, input_file, options=warp_options)
    warp = None  # Closes the files

